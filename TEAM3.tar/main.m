clear; clc; close all;

noisy_speech = load('noisy_speech.txt'); 
external_noise = load('external_noise.txt'); 
clean_speech = load('clean_speech.txt');

%% original SNR
signal_power = sum(clean_speech.^2);
noise_speech_power = sum((clean_speech - noisy_speech).^2);
Original_SNR = 10 * log10(signal_power / noise_speech_power);
fprintf('Original SNR: %.2f dB\n', Original_SNR);

%% RLS, Full-Suppression Mode
fs = 44100;  
frame_size = 32768; % Frame Size
num_taps = 8; % Filter order
lambda = 0.99999; % Forgetting factor

fprintf('Full Suppression\n');
enhanced_signal = rls_filter(noisy_speech, external_noise, frame_size, num_taps, lambda, 0);

rls_noise_power = sum((clean_speech - enhanced_signal).^2);
SNR_RLS = 10 * log10(signal_power / rls_noise_power);
fprintf('SNR after RLS: %.2f dB\n', SNR_RLS);

% % Save Audio
% audiowrite('rls_output.wav', enhanced_signal, fs);
% fprintf('Saved as rls_output.wav\n');

% %% RLS (Ideal) Partial Suppression Mode
% notchFreq = 1000; 
% notchWidth = 20; 
% 
% fprintf('Partial Suppression with Ideal Notch Filter\n');
% ideal_notched_noise = ideal_notch_filter(external_noise, fs, notchFreq, notchWidth);
% partial_ideal_notched = rls_filter(noisy_speech, ideal_notched_noise, frame_size, num_taps, lambda, 0);
% partial_ideal_notched = partial_ideal_notched / (max(abs(partial_ideal_notched)));
% 
% plot_spectrogram(partial_ideal_notched, fs, 1);
% 
% % Save Audio
% audiowrite('ideal_partial.wav', partial_ideal_notched, fs);
% fprintf('Saved as ideal_partial.wav\n');

%% RLS (Practical) Partial Suppression Mode
notchFreq = 1000;
Q = 35;

fprintf('Partial Suppression with Practical Notch Filter\n');
partial_practical_notched = rls_filter(noisy_speech, external_noise, frame_size, num_taps, lambda, 1);
partial_practical_notched = partial_practical_notched / (max(abs(partial_practical_notched)));

plot_spectrogram(partial_practical_notched, fs, 2);

% % Save Audio
% audiowrite('practical_partial.wav', partial_practical_notched, fs);
% fprintf('Saved as practical_partial.wav\n');